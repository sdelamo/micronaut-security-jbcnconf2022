package example

import geb.Page

import io.micronaut.core.annotation.Nullable

class LoginFailedPage extends Page {

    static url = "/loginfailed"

    static at = { title == 'Login Failed' }
}
