package example

import geb.spock.GebSpec
import io.micronaut.context.ApplicationContext
import io.micronaut.runtime.server.EmbeddedServer
import org.openqa.selenium.Cookie
import spock.lang.AutoCleanup
import spock.lang.Shared

class AuthenticationSpec extends GebSpec {

    @AutoCleanup
    @Shared
    EmbeddedServer embeddedServer = ApplicationContext.run(EmbeddedServer)

    ApplicationContext getApplicationContext() {
        embeddedServer.applicationContext
    }

    @Shared
    UserRepository userRepository = applicationContext.getBean(UserRepository)

    def setup() {
        browser.baseUrl = embeddedServer.URL.toString()
    }

    def "user not found login"() {
        when:
        to LoginPage

        then:
        at LoginPage

        when:
        LoginPage loginPage = browser.page(LoginPage)
        loginPage.login('foo', 'bar')

        then:
        at LoginFailedPage
    }

    def "login with DB user"() {
        given:
        String username = 'john'
        String password = 'aegon'

        when:
        userRepository.save(username, password)

        then:
        userRepository.count() == old(userRepository.count()) + 1

        when:
        to LoginPage

        then:
        at LoginPage

        when:
        LoginPage loginPage = browser.page(LoginPage)
        loginPage.login(username, password)

        then:
        at HomePage

        when:
        HomePage homePage = browser.page(HomePage)

        then:
        homePage.username == username

        when:
        Set<Cookie> cookies = browser.driver.manage().cookies

        then:
        cookies.find { cookie -> cookie.name == 'SESSION' }

        when:
        homePage.logout()

        then:
        at HomePage

        and:
        !homePage.username

        cleanup:
        userRepository.delete(username)
    }

    def "login with LDAP user"() {
        when: 'Login with an LDAP user'
        to LoginPage

        then:
        at LoginPage

        when: 'https://www.forumsys.com/tutorials/integration-how-to/ldap/online-ldap-test-server/'
        String ldapUsername = 'euler'
        String ldapPassword = 'password'
        LoginPage loginPage = browser.page(LoginPage)
        loginPage.login(ldapUsername, ldapPassword)

        then:
        at HomePage

        when:
        HomePage homePage = browser.page(HomePage)

        then:
        homePage.username == ldapUsername

        when:
        homePage.logout()

        then:
        at HomePage

        and:
        !homePage.username
    }
}
