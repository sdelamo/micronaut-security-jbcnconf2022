package example;

import io.micronaut.core.annotation.NonNull;
import jakarta.inject.Named;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import jakarta.inject.Singleton;
import javax.validation.constraints.NotNull;

@Named("bcrypt")
@Singleton
public class BCryptPasswordEncoderService implements PasswordEncoder {

    org.springframework.security.crypto.password.PasswordEncoder delegate = new BCryptPasswordEncoder();

    @Override
    @NonNull
    public String encode(@NonNull @NotNull String rawPassword) {
        return delegate.encode(rawPassword);
    }

    @Override
    public boolean matches(String rawPassword, String encodedPassword) {
        return delegate.matches(rawPassword, encodedPassword);
    }
}
