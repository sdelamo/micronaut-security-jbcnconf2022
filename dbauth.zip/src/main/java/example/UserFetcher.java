package example;

import io.micronaut.core.annotation.NonNull;

import javax.validation.constraints.NotBlank;
import java.util.Optional;

public interface UserFetcher {
    @NonNull
    Optional<UserState> findByUsername(@NonNull @NotBlank String username);
}
