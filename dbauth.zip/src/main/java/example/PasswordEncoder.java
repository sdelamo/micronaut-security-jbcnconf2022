package example;

import io.micronaut.core.annotation.NonNull;

import javax.validation.constraints.NotBlank;

public interface PasswordEncoder {
    @NonNull
    String encode(@NonNull @NotBlank String rawPassword);

    boolean matches(String rawPassword, String encodedPassword);
}
