package example;

public interface AppConfiguration {
    String getPrivateKey();
    String getPublicKey();
}
