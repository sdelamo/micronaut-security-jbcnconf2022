package example

import com.nimbusds.jwt.JWT
import com.nimbusds.jwt.JWTParser
import com.nimbusds.jwt.SignedJWT
import example.entities.Role
import io.micronaut.context.ApplicationContext
import io.micronaut.core.type.Argument
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.BlockingHttpClient
import io.micronaut.http.client.HttpClient
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.security.authentication.UsernamePasswordCredentials
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

class BookControllerSpec extends Specification {

    @AutoCleanup
    @Shared
    EmbeddedServer embeddedServer = ApplicationContext.run(EmbeddedServer)

    ApplicationContext getApplicationContext() {
        embeddedServer.applicationContext
    }

    @AutoCleanup
    @Shared
    HttpClient httpClient = applicationContext.createBean(HttpClient, embeddedServer.URL)

    BlockingHttpClient getClient() {
        httpClient.toBlocking()
    }

    void "there is an BookController bean"() {
        expect:
        applicationContext.containsBean(BookController)
    }

    void "/books endpoint is available for authenticated users"() {
        given:
        String authority = "ROLE_USER"
        String username = "john"
        String password = "aeon"

        when:
        UserRepository userRepository = applicationContext.getBean(UserRepository)

        then:
        noExceptionThrown()

        when:
        RoleRepository roleRepository = applicationContext.getBean(RoleRepository)

        then:
        noExceptionThrown()

        when:
        userRepository.save(username, password)

        then:
        userRepository.count() == old(userRepository.count()) + 1

        when:
        Role role = roleRepository.save(authority)

        then:
        roleRepository.count() == old(roleRepository.count()) + 1

        when:
        userRepository.addUserRole(username, role)

        then:
        userRepository.findRolesByUsername(username).size() == old(userRepository.findRolesByUsername(username).size()) + 1

        when:
        HttpRequest request = HttpRequest.POST('/login', new UsernamePasswordCredentials(username, password))
        HttpResponse<Map> response = client.exchange(request, Map)

        then:
        response.status == HttpStatus.OK

        when:
        String accessToken = 'XXX' // TODO from the login response obtain an access token

        then:
        accessToken

        when:
        JWT jwt = JWTParser.parse(accessToken)

        then:
        jwt instanceof SignedJWT

        when:
        HttpRequest req = HttpRequest.GET("/books") //TODO Add Authorization Header and pass the access token
        HttpResponse<List<Book>> resp = client.exchange(req, Argument.of(List, Book))

        then:
        noExceptionThrown()
        resp.status() == HttpStatus.OK

        when:
        List<Book> books = resp.body()

        then:
        books
        books.size() == 3
        books.find { new Book("1491950358", "Building Microservices") }
        books.find { new Book("1680502395", "Release It!") }
        books.find { new Book("0321601912", "Continuous Delivery") }

        cleanup:
        userRepository.delete(username)
        roleRepository.delete(authority)
    }
}
